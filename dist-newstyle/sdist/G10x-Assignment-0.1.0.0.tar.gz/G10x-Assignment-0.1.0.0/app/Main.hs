{-# LANGUAGE OverloadedStrings #-}

import Data.Aeson(encode, toJSON, ToJSON, object, (.=))
import Text.Read(readMaybe)
import Data.HashMap.Strict (HashMap)
import qualified Data.HashMap.Strict as HM
import Data.Text (Text)
import qualified Data.Text as T
import Data.Maybe (catMaybes)
import Data.List.Split (splitOn)
import Servant


import Debug.Trace(trace)

data ValueType = ValueType String deriving Show

data Value
  = VDate String
  | VNumber Int
  | VString String
  | VBool Bool
  | VArray String [Value]
  deriving Show

instance ToJSON Value where
  toJSON (VDate str)      = object ["type" .= ("date" :: Text), "value" .= str]
  toJSON (VNumber num)    = object ["type" .= ("number" :: Text), "value" .= num]
  toJSON (VString str)    = object ["type" .= ("string" :: Text), "value" .= str]
  toJSON (VBool bool)     = object ["type" .= ("bool" :: Text), "value" .= bool]
  toJSON (VArray vt vals) = object ["type" .= show vt, "values" .= vals]

data Pair = Pair String Value deriving Show

parseEncodedValue :: String -> String -> Maybe Value
parseEncodedValue ('0':'0':restKey) rest    = parseDate rest
parseEncodedValue ('1':'0':restKey) rest    = parseArray (ValueType "0") rest
parseEncodedValue ('0':'1':restKey) rest    = parseNumber rest
parseEncodedValue ('1':'1':restKey) rest    = parseArray (ValueType "1") rest
parseEncodedValue ('0':'2':restKey) rest    = parseString rest
parseEncodedValue ('1':'2':restKey) rest    = parseArray (ValueType "2") rest
parseEncodedValue ('0':'3':restKey) rest    = parseBool rest
parseEncodedValue ('1':'3':restKey) rest    = parseArray (ValueType "3") rest
parseEncodedValue _ _ = Nothing

parseDate :: String -> Maybe Value
parseDate str =
  let [year, month, day] = splitOn "-" str
   in Just $ VDate (year ++ "-" ++ month ++ "-" ++ day)

parseNumber :: String -> Maybe Value
parseNumber str = VNumber <$> readMaybe str

parseString :: String -> Maybe Value
parseString str = Just $ VString str

parseBool :: String -> Maybe Value
parseBool "y" = Just $ VBool True
parseBool "Y" = Just $ VBool True
parseBool "t" = Just $ VBool True
parseBool "T" = Just $ VBool True
parseBool "n" = Just $ VBool False
parseBool "N" = Just $ VBool False
parseBool "f" = Just $ VBool False
parseBool "F" = Just $ VBool False
parseBool _ = Nothing

parseArray :: ValueType -> String -> Maybe Value
parseArray (ValueType value) str = do
  let values = splitOn "," str
  let parsedValues = catMaybes $ map (parseEncodedValue ('0' : value)) values
  Just $ VArray (getTypeForArray (ValueType value)) parsedValues

parseKeyValuePair :: String -> Maybe Pair
parseKeyValuePair str = do
  let (key, value) = break (== '|') str
  parsedValue <- parseEncodedValue key (drop 1 value)
  Just $ Pair key parsedValue

parseToJSON :: String -> Maybe (HashMap Text Value)
parseToJSON input = do
  let pairs = splitOn "#" input
  let parsedPairs = catMaybes $ map parseKeyValuePair pairs
  let keyValuePairs = map (\(Pair key value) -> (T.pack (drop 2 key), value)) parsedPairs
  Just $ HM.fromList keyValuePairs


getTypeForArray :: ValueType -> String 
getTypeForArray (ValueType value)
    | value == "0" = "Array of Date"
    | value == "1" = "Array of Number"
    | value == "2" = "Array of String"
    | value == "3" = "Array of Bool"
    | otherwise = "Unknown"

-- main :: IO ()
-- main = do
--   let encodedString = "#00date|1997-02-06#02name|bob#01age|20#03hasPassport|Y#13access|y,n,F,f"
--   let maybeJson = parseToJSON encodedString
--   case maybeJson of
--     Just json -> do 
--       print (encode (toJSON json))
--       print("hello")
--     Nothing -> putStrLn "Invalid encoding format"


type JSONAPI = "parse" :> QueryParam "data" String :> Get '[JSON] (Maybe (HashMap Text Value))

jsonAPI :: Proxy JSONAPI
jsonAPI = Proxy

server :: Server JSONAPI
server = parseData

parseData :: Maybe String -> Handler (Maybe (HashMap Text Value))
parseData maybeEncodedString = case maybeEncodedString of
  Just encodedString -> return $ parseToJSON encodedString
  Nothing -> throwError err400 { errBody = "Invalid data" }

app :: Application
app = serve jsonAPI server

main :: IO ()
main = run 8080 app